// Select elements
const taskInput = document.getElementById('task-input');
const addTaskButton = document.getElementById('add-task-button');
const taskList = document.getElementById('task-list');

// Function to add a task
function addTask() {
    const taskText = taskInput.value.trim();
    if (taskText === '') {
        alert('Please enter a task!');
        return;
    }

    // Create list item
    const listItem = document.createElement('li');
    listItem.classList.add('task-item');

    // Task content
    const taskContent = document.createElement('span');
    taskContent.textContent = taskText;

    // Complete button
    const completeButton = document.createElement('button');
    completeButton.textContent = '✔';
    completeButton.classList.add('complete');
    completeButton.onclick = () => {
        listItem.classList.toggle('completed');
    };

    // Delete button
    const deleteButton = document.createElement('button');
    deleteButton.textContent = '✖';
    deleteButton.classList.add('delete');
    deleteButton.onclick = () => {
        taskList.removeChild(listItem);
    };

    // Append elements
    listItem.appendChild(taskContent);
    listItem.appendChild(completeButton);
    listItem.appendChild(deleteButton);
    taskList.appendChild(listItem);

    // Clear input field
    taskInput.value = '';
}

// Event listener for adding a task
addTaskButton.addEventListener('click', addTask);

// Add task on pressing Enter
taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        addTask();
    }
});